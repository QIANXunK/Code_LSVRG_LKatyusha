#ifndef LOGISTIC_REGRESSION_L_KATYUSHA
#define LOGISTIC_REGRESSION_L_KATYUSHA
#include <math.h> //log ; exp;

#include "Primal_Dual_LOOPLESS_Katyusha0.h"



/*
The optimization problem to solve is:

           \frac{1}{n}\sum_{i=1}^n \phi_i(A_i^{\top} w)+\lambda g(w)
Assumption 1: For each i, \phi_i is 1/\gamma-smooth
Assumption 2: g is 1-strongly convex


*/

/*
The Loss function is the Logistic Loss function:

                   \phi_i(x)=4*log(1+exp(x))/gamma

Note that \phi_i  is 1/\gamma-smooth

The dual loss function \phi_i^* is then:
		    if(x\in[0,4/\gamma])
                       \phi_i^*(x)=-x*log(\frac{4-\gamma x}{\gamma x})-\frac{4}{\gamma}log(\frac{4}{4-\gamma x})
                    else
		      \phi_i^*(x)=inf
*/

/*
g is the L_1+L_2 regularizer:
g(w)=\frac{\lambda_2}{2}\|w\|^2+\lambda1\|w\|_1
* if lambda_2>0
g^*(x)=\frac{1}{2*lambda_2}\sum_{i=1}^d [(|x_i|-\lambda1)_+]^2
\nabla_j g^*(x)=sign(x_i)[|x_i|-lambda1]_+*1./lambda_2
* otherwise
*                     g^*(x)=1_{-\lambda1\leq x\leq \lambda1}
*                     \nabla g^*(x)=0 if x\in (-lambda1, lambda1); (-\infty, 0] if x=-lambda1; [0,+\infty) if x=lambda1
If \lambda1=0, g is the L_2 regularizer.
*/





template<typename L, typename D>
class Logistic_Regression_L_Katyusha: public Primal_Dual_LOOPLESS_Katyusha0<L, D> {



  public:

    D lambda1;               // L_1 regularizer parameter;

    D lambda2;       // L_2 regularizer parameter



    Logistic_Regression_L_Katyusha(const char* matrix_file, const char* vector_file, D sig)
    :Primal_Dual_LOOPLESS_Katyusha0<L,D>(matrix_file,vector_file)
    {
      lambda1=sig;
      this->gamma=1;
      for(L i=0;i<this->nsamples;i++)
      {
        for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) {
          this->A[k]*=this->b[i];
        }
      }
      for(L j=0;j<this->nfeatures;j++)
      {
        for (L k = this->ptr_t[j]; k < this->ptr_t[j + 1];k++) {
          L i=this->col_idx[k];
          this->A_t[k]*=this->b[i];
        }
      }

    }

    Logistic_Regression_L_Katyusha(const char* matrix_file, D sig)
    :Primal_Dual_LOOPLESS_Katyusha0<L,D>(matrix_file)
    {
      lambda1=sig;
      this->gamma=1;
      for(L i=0;i<this->nsamples;i++)
      {
        for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) {
          this->A[k]*=this->b[i];
        }
      }
      for(L j=0;j<this->nfeatures;j++)
      {
        for (L k = this->ptr_t[j]; k < this->ptr_t[j + 1];k++) {
          L i=this->col_idx[k];
          this->A_t[k]*=this->b[i];
        }
      }

    }

    inline void set_auxiliary_v(){
      lambda2=this->mu;
    }



    inline D value_of_phi_i(D x, L i) {
      if(x>=0)
         return 4*(x+log(1+exp(-x)))/this->gamma;
     else
         return 4*log(1+exp(x))/this->gamma;
    }



    inline D gradient_of_phi_i(D x, L i){
     return 4.0/(1.0+exp(-x))/this->gamma;

    }




    inline D value_of_phistar_i(D x, L i) {
     if(x>0&&(x<4.0/this->gamma))
       return x*log((this->gamma*x))+(4/this->gamma-x)*log((4-this->gamma*x))-4/this->gamma*log(4);
     else if(x>=4.0/this->gamma&&x<4.0/this->gamma+1e-10 ) return 0.0;
     else if(x<=0&&x>-1e-10) return 0.0;
      else {cout<<setprecision(16)<<x<<endl; return 1.0/0.0;}
    }



    inline D gradient_of_gstar_j(D x, L j){
      if(lambda2>0)
      return ((x>0)-(x<0))*(max(fabs(x)-lambda1,0.0))/lambda2;
      else
      return 0;
    }

    inline D value_of_g_j(D x, L j){
      return lambda2*x*x/2+lambda1*fabs(x);
    }



    inline D value_of_gstar(vector<D> & x){

      if(lambda2>0)
      {
        D res=0;
        D ip=0;
        L l=x.size();
        for(L i=0;i<l;i++)
        {
          ip=max(fabs(x[i])-lambda1,0.0);
          res+=ip*ip;
        }
        return res/2/lambda2;
      }
      else
      {
          return 0;
      }
    }
inline D get_lambda1(){return lambda1;}
inline D get_lambda2(){return lambda2;}
    inline D feasible_dual(vector<D> & x){

      if(lambda2>0)
      {
          return 1;
      }
      else
      {
          D scal=1;
          L l=x.size();
          for(L i=0;i<l;i++)
              if(fabs(x[i])>lambda1)
            scal=min(lambda1/fabs(x[i]),scal);
          return scal;
      }
    }

    //We implement Section 6.2 of SPDC paper for 'just-in-time' update
    //t0 is t0+1 in the paper SPDC ; x is the z vector in Katyusha
    inline void compute_just_in_time_prox_grad(D tau, D u, D &x, L t0,L t1, D w, D &y){
      if(t0==t1)
        return;
      else{
          if(lambda2>0)
          {
            D theta=1./(1+lambda2*tau);
            D hplus=(u+lambda1)/lambda2;
            D hminus=(u-lambda1)/lambda2;
            D p=pow(theta,t1-t0);
            if(lambda1==0){
               y=compute_aid_2(p,theta, hplus, t1-t0, x, y, w);
               x=p*(x)-(1-p)*u/lambda2;
            }else{
               if(x==0){
                 if(lambda1+u<0){
                  y=compute_aid_2(p,theta, hplus, t1-t0, x, y, w);
                  x=p*x-(1-p)*hplus;
                 }
            else if(u-lambda1>0){
               y=compute_aid_2(p,theta, hminus, t1-t0, x, y, w);
               x=p*x-(1-p)*hminus;
            }else{
              x=0;
              D p2=pow(this->theta3,t1-t0);
              D tmp2=(1-p2)/(this->theta1+this->theta2);
              y=(this->theta2*w)*tmp2+p2*y;
            }
          }else if(x>0){
            if(lambda1+u<=0){
               y=compute_aid_2(p,theta, hplus, t1-t0, x, y, w);
               x=p*x-(1-p)*hplus;
            }else{
              D t=t0-log(1+lambda2*x/(lambda1+u))/log(theta);
              if(t<t1){
              L t_tmp=floor(t);
              p=pow(theta,t_tmp-t0);
               y=compute_aid_2(p,theta, hplus, t_tmp-t0, x, y, w);
               x=p*x-(1-p)*hplus;
                x=compute_one_step(tau,u,x);
                y=this->theta1*x+this->theta2*w+this->theta3*y;
                compute_just_in_time_prox_grad(tau, u,  x,  t_tmp+1, t1, w, y);
              }
              else{
               y=compute_aid_2(p,theta, hplus, t1-t0, x, y, w);
               x=p*x-(1-p)*hplus;
              }
            }

          }else if(x<0){
              D minusw=-w;
              D minusx=-x;
              D minusy=-y;
              compute_just_in_time_prox_grad(tau, -u,  minusx,  t0, t1,minusw, minusy);
              x=-minusx;
              y=-minusy;
          }

        }

          }
          else{

        if(lambda1==0){
             y=compute_aid(tau*u, t1-t0, x, y, w);
             x=x-(t1-t0)*tau*u;
        }
        else{
          if(x==0){
            if(lambda1+u<0){
                y=compute_aid(tau*(lambda1+u), t1-t0, x, y, w);
                x=x-(t1-t0)*tau*(lambda1+u);
            }
            else if(u-lambda1>0){
                y=compute_aid(tau*(-lambda1+u), t1-t0, x, y, w);
                x=x-(t1-t0)*tau*(u-lambda1);
            }else{
              D p2=pow(this->theta3,t1-t0);
              D tmp2=(1-p2)/(this->theta1+this->theta2);
              y=(this->theta2*w)*tmp2+p2*y;
              x=0;
            }
          }else if(x>0){
            if(lambda1+u<=0){
                y=compute_aid(tau*(lambda1+u), t1-t0, x, y, w);
                x=x-(t1-t0)*tau*(lambda1+u);
            }else{
              D t=t0+x/(lambda1+u);
              if(t<t1){
                L t_tmp=floor(t);
                y=compute_aid(tau*(lambda1+u), t_tmp-t0, x, y, w);
                x=x-(t_tmp-t0)*tau*(lambda1+u);
                x=compute_one_step(tau,u,x);
                y=this->theta1*x+this->theta2*w+this->theta3*y;
                compute_just_in_time_prox_grad(tau, u,  x,  t_tmp+1, t1, w, y);
              }
              else{
                 y=compute_aid(tau*(lambda1+u), t1-t0, x, y, w);
                 x=x-(t1-t0)*tau*(lambda1+u);
              }
            }

          }else if(x<0){
              D minusw=-w;
              D minusx=-x;
              D minusy=-y;
              compute_just_in_time_prox_grad(tau, -u,  minusx,  t0, t1,minusw, minusy);
              x=-minusx;
              y=-minusy;
          }

        }
          }
      }

    };


    // compute_aid returns the value of y_{k+s} given by: y_{k+1}=theta1*z_{k+1}+theta2*w+(1-theta1-theta2)*y_k; z_{k+i}=z_k-i*h
    D compute_aid(D h, D s, D x, D y, D w){
             D p2=pow(this->theta3,s);
             D tmp2=(1-p2)/(this->theta1+this->theta2);
             D tmp3=(tmp2*this->theta3-p2*s)/(this->theta1+this->theta2);
             y=this->theta1*(tmp2*(x-s*h)+h*tmp3)+this->theta2*w*tmp2+p2*y;
             return y;
    }


    // compute_aid_2 returns the value of y_{k+s} given by: y_{k+1}=theta1*z_{k+1}+theta2*w+(1-theta1-theta2)*y_k; z_{k+i}=q^i(z_k+h)-h
//p=q^s;
     D compute_aid_2(D p, D q, D h, D s, D x, D y, D w){
               D theta3overq=this->theta3/q;
               D p2=pow(this->theta3,s);
               D p3=pow(theta3overq,s);
               D tmp=(1-p3)/(1-theta3overq);
               D tmp2=(1-p2)/(this->theta1+this->theta2);
               y=this->theta1*p*(x+h)*tmp+(this->theta2*w-this->theta1*h)*tmp2+p2*y;
             return y;
    }


    D compute_one_step(D tau, D u, D x){
      D new_x;
      if(x>tau*(lambda1+u))
      new_x=(x-tau*(lambda1+u))/(1+lambda2*tau);
      else if(x<tau*(u-lambda1))
      new_x=(x-tau*(u-lambda1))/(1+lambda2*tau);
      else
      new_x=0;
      return new_x;
    }







};

#endif /* LOGISTIC_REGRESSION */
