
close all;

prompt='What are the values of lambda?\n';
l1=input(prompt);

prompt='What are the values of gamma?\n';
l2=input(prompt);

prompt='What are the values of sigma?\n';
sig=input(prompt);
%l1=[1 2 3   ]; %values of lambda1 
%l2=[  1  ];  %values of lambda2



%prompt='enter 5 if plot time, enter 6 if plot nb of iterations \n';
%pi=input(prompt);

prompt='What is the problem type?\n';
problems=input(prompt);
%problem='lasso';
prompt='What is the file name?\n';
filenames=input(prompt);
%filename='rcv1';


    
    for f=1:length(filenames)
        filename=filenames{f};
        for pr=1:length(problems)
            problem=problems{pr};
    for i=1:length(l1)
        for j=1:length(l2)
        for k=1:length(sig)
        
        %close all;
        figure('Units','inches','Position',[0.1,0.5,5,5],'PaperPositionMode','auto');

        %subplot(length(l1),length(l2),(i-1)*length(l2)+j);

L1=l1(i);

L2=l2(j);

s=sig(k);

pi=1;
plotfile2(filename, problem, 'SPDC',L1,L2,s,pi);
plotfile2(filename, problem, 'SDCA',L1,L2,s,pi);
plotfile2(filename, problem, 'SAGA',L1,L2,s,pi);


%legends={'GD','FISTA','AdapAPG','AdaAGC','AdaRES'};
legends={'SPDC','SDCA','SAGA'};

[hleg1, hobj1] = legend(legends);
textobj = findobj(hobj1, 'type', 'text');
set(hleg1, 'Interpreter', 'latex', 'fontsize', 14);
set(textobj,'fontsize',14);
legend1=legend(legends);
set( gca                       , ...
    'FontName'   , 'Helvetica' );

set(legend1,'Location','northeast','FontSize',14);
set(gca,'fontsize',20);
ll2=10^L2;
ll1=10^L1;




 

% if(length(filename)>8)
% title([filename(1:8) ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% else
% title([filename ';  {\lambda_1}=', num2str(ll1),';  {\mu_0}=',num2str(mu0) ]);
% end

if pi==1
xlabel('nb of epochs');
 else if pi==5 
  xlabel('time');
end
end
ylabel('log(Primal Dual Gap)')
h=['myplots/', filename, num2str(L1), num2str(L2),    '.eps'];

if pi==1
  h=['myplots/', filename, num2str(L1), num2str(L2),    '_i.eps'];
end
h
    
print(h,'-depsc2');
    end
end
        end
        end
    end

