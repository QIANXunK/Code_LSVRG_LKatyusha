function plotfile2_uni_nonuni(filename, problem, method, uni)


hold on;

lw=3;


    switch method
    case 'SAGA'
        lins='-';

       
        case 'SDCA'
        
         lins=':';
            
    end
     switch uni
    case 'uniform'
         
        mark='none';
        color='c';
        lw=4;
        facecolor=[.75 .75 1];
        case 'nonuniform'
         mark='*';
         
        color=[0 .5 .0];
        facecolor=[.7 .7 .7];       
    end
  name=['../results/', method, '_',  problem, '_',filename,'tau1lambda-5',uni];

name
h=dlmread(name);

size(h,1)
size(h,2)


px=1:size(h,1);
px=1:5:size(h,1);

hp=plot(h(px,1),h(px,2));

min(abs(h(:,2)))
set(gca, 'YScale', 'log');
ylim([0, 1 ]);
xlim([0,100]);

set(hp                           , ...
  'LineStyle'       , lins      , ...
  'Marker'          , mark       , ...
  'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end






 







