function g=gradient_j(x,j)
global A  mu;
 y=A(j,:)*x;
 tmp=4/(exp(-y)+1);
 g=A(j,:)*tmp;
 g=g'+mu*x;
end