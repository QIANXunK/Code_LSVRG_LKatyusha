function plotfile2_scalep(filename, problem, method,tau,lambda,scaler,plot_time,uniform,batch)
global plotlength;

hold on;

lw=2;

switch scaler
    case 1
        lins='--';
         mark='+';
        facecolor=[.75 .75 1];
    case 10
        lins='-';
         mark='o';
        facecolor=[0.7 .7 .7];
    case 50
        lins=':';
        mark='s';
        facecolor=[.7 .7 .7];    
end

switch method
    case 'L_SVRG'  
        color='b';
        st=10;
   case 'L_Original_Katyusha'  
        color='m';
        st=2;
    case 'L_Katyusha'
        color='r';
        st=2;
      
end
name=['../../results/forplots/', method, '',  problem, '_',filename,'tau',num2str(tau),'lambda_',num2str(lambda),uniform,'_',batch,num2str(scaler)];
name
h=dlmread(name);

size(h,1)
size(h,2)
h




if(plot_time==0)
    if(size(h,1)>30)
    px=[st:20 25:ceil((size(h,1)-25)/20):size(h,1)];
    else
   
        px=st:size(h,1);
    end
    
    hp=plot(h(px,1),h(px,2));
    plotlength=max(plotlength,min(max(h(:,1)),3000));
    else
     if(size(h,1)>30)
    px=st:ceil(size(h,1)/20):size(h,1);
     else
        px=st:size(h,1);
     end
    hp=plot(h(px,3),h(px,2));
    px
    plotlength=max(plotlength,min(max(h(:,3)),3000));
end
min(abs(h(:,2)))
set(gca, 'YScale', 'log');
ylim([0, 1]);
xlim([0,plotlength]);

set(hp                           , ...
    'LineStyle'       , lins      , ...
    'Marker'          , mark       , ...
    'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end








