function f=value_f(x)
global A mu m;
 y=A*x;
 tmp=4*log(1+exp(y));
 f=sum(tmp)/m+mu*x'*x;
end