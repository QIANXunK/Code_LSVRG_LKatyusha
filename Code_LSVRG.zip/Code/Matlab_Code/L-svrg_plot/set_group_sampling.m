function set_group_sampling()
global m proba Groups iP;

[sp,iP]=sort(proba);


res=0;
current_gp=1;
Groups=zeros(m,4);
Groups(current_gp,1)=1;
maxpi=0;
for i=1:m
    pi=sp(i);   
    if(res+ps>1) 
        Groups(current_gp, 2)=i;
         Groups(current_gp, 3)=res;
          Groups(current_gp, 4)=maxpi;
        Groups(current_gp+1,1)=i;
        maxpi=pi;
        current_gp=current_gp+1;
    else
        maxpi=max(pi,maxpi);    
        res=res+pi;  
        if(i==m)
            Groups(current_gp, 2)=i;
            Groups(current_gp, 3)=res;
            Groups(current_gp, 4)=maxpi;
        end
    end
    
end
