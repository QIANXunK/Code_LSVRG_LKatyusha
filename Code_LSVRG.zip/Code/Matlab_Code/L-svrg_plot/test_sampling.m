n=1000;
m=100000;
p=rand(n,1);



p(1:100)=p(1:100)*0.001;


p(500:600)=p(500:600)*0.003;

p=p/sum(p);
 
maxp=max(p);


ki=0;
S=zeros(m,1);
for k=1:m
    i=randi(n);
y=rand(1);
ki=ki+1;
while(y*maxp>p(i))
    i=randi(n);
    y=rand(1);
    ki=ki+1;
end
S(k,1)=i;
end

hist(S)

