
close all;

global plotlength;

plotlength=1;
problems={'Logistic'};
filenames={'cod_rna'};

methods={'L_Katyusha'};
lambdas={0.01};
scaler_ps={1};

uniform='nonuniform';
batch='batch';

plot_time=1; %plot_time=0 if plot with epochs
tau_s={50};

for f=1:length(filenames)
    filename=filenames{f};
    for pr=1:length(problems)
        problem=problems{pr};
            for lm=1:length(lambdas)
                lambda=lambdas{lm};
                for sm=1:length(scaler_ps)
                    scaler=scaler_ps{sm};
                     for sm=1:length(tau_s)
                    tau=tau_s{sm};
                    plotlength=1;
                    %name=['../results/', method, '_',  problem, '_',filename,'lambda',num2str(lambda)];
                    
                    %close all;
                    figure('Units','inches','Position',[0.1,0.5,4.5,3.5],'PaperPositionMode','auto');
                    
      
                    plotfile2_c_batch_group(filename, problem, 'L_Original_Katyusha',tau,lambda,scaler,plot_time,uniform,'batch');
                   
                    plotfile2_c_batch_group(filename, problem, 'L_Katyusha',tau,lambda,scaler,plot_time,uniform,'group');
                   
                    
                    
                    switch uniform
                        case 'uniform'
                            my_method='';
                        case 'nonuniform'
                            my_method='IP ';
                    end
                    
                    legends={['L\_Katyusha ',my_method, ' SP'],['L\_Katyusha ',my_method, ' GS']};
                   %legends={['L\_Katyusha ','tau=',num2str(tau)],['Katyusha tau=',num2str(tau)]};
                    [hleg1, hobj1] = legend(legends);
                    textobj = findobj(hobj1, 'type', 'text');
                    set(hleg1, 'Interpreter', 'latex', 'fontsize', 10);
                    set(textobj,'fontsize',10);
                    legend1=legend(legends);
                    set( gca                       , ...
                        'FontName'   , 'Helvetica' );
                    
                    set(legend1,'Location','northeast','FontSize',10);
                    set(gca,'fontsize',10);
                    
                    if(plot_time==0)
                        xlabel('epoch');
                    else
                        xlabel('time');
                    end
                    
                    lambdastr=1;
                     switch lambda
                         case 1e-5
                            lambdastr='10^{-5}';
                           case 1e-2
                            lambdastr='10^{-2}';
                            case 1e-3
                            lambdastr='10^{-3}';
                            case 1e-4
                            lambdastr='10^{-4}';
                            case 1e-6
                            lambdastr='10^{-6}';
                            case 1e-7
                            lambdastr='10^{-7}';
                         case 1e-1
                             lambdastr='10^{-1}';
                             case 1
                             lambdastr='1';
                     end
                    
                    switch lambda
                         case 1e-5
                            lambdastr2='1e-5';
                           case 1e-2
                            lambdastr2='1e-2';
                            case 1e-3
                            lambdastr2='1e-3';
                            case 1e-4
                            lambdastr2='1e-4';
                            case 1e-6
                            lambdastr2='1e-6';
                            case 1e-7
                            lambdastr2='1e-7';
                         case 1e-1
                             lambdastr2='1e-1';
                             case 1
                             lambdastr2='1';
                    end
                    
                      h=['myplots/c_w_b_g_', filename, lambdastr2, num2str(plot_time),'.eps'];
                    switch filename
                        case 'cod_rna'
                            filename2='cod\_rna';
                        case 'w8a'
                            filename2='w8a';
                    end
                    title([filename2,' \lambda_2=', lambdastr ]);
                    ylabel('primal dual gap');
                  
                    print(h,'-depsc2');
                end
            end
        end

    end

end
  

