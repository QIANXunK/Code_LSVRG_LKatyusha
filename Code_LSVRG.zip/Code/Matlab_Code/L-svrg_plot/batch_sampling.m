function S=batch_sampling(tau)
global m tilde_p;
S=zeros(tau,1);
maxp=max(tilde_p);
for k=1:tau
    i=randi(m);
    y=rand(1);
    while(y*maxp>tilde_p(i))
    i=randi(m);
    y=rand(1);
    end
    S(k)=i;
end
end