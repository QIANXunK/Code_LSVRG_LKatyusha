function S=group_sampling()
global m proba Groups iP;

g_l=size(Groups,1);
tau=0;
for i=1:g_l
    y=rand(1);
    pi=Groups(i,3);
    if(y<=pi) 
        tau=tau+1;
    end
end
S=zeros(tau,1);

for i=1:tau
    s1=Groups(i,1);
    s2=Groups(i,2);
    maxp=Groups(i,4);
    for k=1:tau
    ki=s1+randi(s2-s1)-1;
    j=iP(ki);
    y=rand(1);
    while(y*maxp>proba(j))
    ki=s1+randi(s2-s1)-1;
    j=iP(ki);
    y=rand(1);
    end
    S(k)=j;
end
    
end
S=zeros(tau,1);
maxp=max(tilde_p);
for k=1:tau
    i=randi(m);
    y=rand(1);
    while(y*maxp>tilde_p(i))
    i=randi(m);
    y=rand(1);
    end
    S(k)=i;
end
end