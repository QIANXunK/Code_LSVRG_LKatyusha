
close all;

global plotlength;

plotlength=1;
problems={'Logistic'};
filenames={'cod_rna'};

methods={'L_Katyusha'};
lambdas={0.01};
scaler_ps={1};

uniform='nonuniform';
batch='batch';

plot_time=0; %plot_time=0 if plot with epochs


for f=1:length(filenames)
    filename=filenames{f};
    for pr=1:length(problems)
        problem=problems{pr};
        for pm=1:length(methods)
            method=methods{pm};
            switch method
    case 'L_SVRG'
        my_method='L\_SVRG';
    case 'L_Katyusha'
        my_method='L\_Katyusha';
end

            for lm=1:length(lambdas)
                lambda=lambdas{lm};
                for sm=1:length(scaler_ps)
                    scaler=scaler_ps{sm};
                    plotlength=1;
                    name=['../results/', method, '_',  problem, '_',filename,'lambda',num2str(lambda)];
                    
                    %close all;
                    figure('Units','inches','Position',[0.1,0.5,3.5,4.5],'PaperPositionMode','auto');
                    
      
                    plotfile2_tau(filename, problem, method,1,lambda,scaler,plot_time,uniform,batch);
                    plotfile2_tau(filename, problem, method,10,lambda,scaler,plot_time,uniform,batch);
                    plotfile2_tau(filename, problem, method,50,lambda,scaler,plot_time,uniform,batch);
                    
                    legends={[my_method, '\tau=1'],[my_method, '\tau=10'], [my_method, '\tau=50']};
                    
                    [hleg1, hobj1] = legend(legends);
                    textobj = findobj(hobj1, 'type', 'text');
                    set(hleg1, 'Interpreter', 'latex', 'fontsize', 10);
                    set(textobj,'fontsize',10);
                    legend1=legend(legends);
                    set( gca                       , ...
                        'FontName'   , 'Helvetica' );
                    
                    set(legend1,'Location','northeast','FontSize',10);
                    set(gca,'fontsize',10);
                    
                    if(plot_time==0)
                        xlabel('epoch');
                    else
                        xlabel('time');
                    end
                    title([filename,' \lambda_2=', num2str(lambda) ]);
                    ylabel('primal dual gap');
                    h=['myplots/', filename , method, num2str(lambda),'.eps'];
                    print(h,'-depsc2');
                end
            end
        end
    end
end
      
  

