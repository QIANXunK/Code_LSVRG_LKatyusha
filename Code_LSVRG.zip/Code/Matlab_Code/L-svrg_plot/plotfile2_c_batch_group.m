function plotfile2_c_batch_group(filename, problem, method,tau,lambda,scaler,plot_time,uniform,batch)
global plotlength;

hold on;

lw=2;


switch batch
    case 'group'

         mark='+';
        facecolor=[.75 .75 1];
    case 'batch'
        
         mark='o';
        facecolor=[0.7 .7 .7];

end

switch method
    case 'L_Original_Katyusha'  
        color='b';
       lins='-';
    case 'L_Katyusha'
        color='r';
      lins='--';
end
name=['../../results/forplots/', method, '',  problem, '_',filename,'tau',num2str(tau),'lambda_',num2str(lambda),uniform,'_',batch,num2str(scaler)];
name
h=dlmread(name);

size(h,1)
size(h,2)







if(plot_time==0)
    if(size(h,1)>30)
    px=[1:20 25:ceil((size(h,1)-25)/20):size(h,1)];
    else
   
        px=1:size(h,1);
    end
    px
    hp=plot(h(px,1),h(px,2));
    plotlength=max(plotlength,min(max(h(:,1)),3000));
    else
     if(size(h,1)>30)
    px=1:ceil(size(h,1)/20):size(h,1);
     else
        px=1:size(h,1);
     end
    hp=plot(h(px,3),h(px,2));
    plotlength=max(plotlength,min(max(h(:,3)),3000));
end
min(abs(h(:,2)))
set(gca, 'YScale', 'log');
ylim([0, 1 ]);
xlim([0,plotlength]);

set(hp                           , ...
    'LineStyle'       , lins      , ...
    'Marker'          , mark       , ...
    'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end








