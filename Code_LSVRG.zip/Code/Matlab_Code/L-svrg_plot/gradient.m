
function g=gradient(x)
global A mu m;
 y=A*x;
 tmp=4./(exp(-y)+1);
 g=A'*tmp/m+mu*x;
end