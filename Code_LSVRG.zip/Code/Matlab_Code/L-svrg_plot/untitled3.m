
global A  mu m proba Groups iP;

n=20;
m=100;
%A=rand(m,n);
%A(1:10,:)=-A(1:10,:)*100;
%A(50:65,:)=A(50:65,:)*56;


x=zeros(n,1);
y=x;
z=x;
w=x;

K=10000;
f_val=zeros(K,1);

mu=1e-6;
tau=50;

C=A*A';
Li=diag(C);
tilde_p=Li/sum(Li);

%tilde_p=ones(m,1)*(1.0/m);

Lf=max(eig(C))/m;
L2=max(Li./tilde_p)/m/tau;
theta_S=tau*tilde_p;

L=max(Lf,L2);
theta2=L2/2/L;

p=(tau+0.0)/m;
tmp1=mu/L2/p;
tmp2=Lf*p/L2;
if(tmp2<=1)
    if(tmp1>=1)
        theta1=theta2;
    else
        theta1=sqrt(tmp1)*theta2;
    end
else
    theta1=min(sqrt(mu/Lf),p/2);
end

eta=1/3/theta1;
sigma1=mu/L;

g0=gradient(w);
for k=1:K
    x=theta1*z+theta2*w+(1-theta1-theta2)*y;
    S=batch_sampling(tau);
    g=g0;
    for i=1:length(S)
        j=S(i);
        g=(gradient_j(x,j)-gradient_j(w,j))/n/theta_S(j)+g;
    end
    z1=(eta*sigma1*x+z-eta/L*g)/(1+eta*sigma1);
    y=x+theta1*(z1-z);
    z=z1;
    tmp=rand(1);
    if(tmp<=p) 
        w=x;
        g0=gradient(w);
    end
    f_val(k)=value_f(x);
%     if(k>10&&f_val(k)>f_val(k-1)) 
%         w=x;
%         y=x;
%         z=x;
%         g0=gradient(w);
%     end
end

plot(1:k,f_val);