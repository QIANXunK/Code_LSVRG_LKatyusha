function plotfile2_tau_vs_ind(filename, problem, method,Tau)


hold on;

lw=3;




for i1=1:length(Tau)
    tau=Tau(i1);
    
    switch method
    case 'SAGA-IP'
        
        mark='none';
        color='b';
        lw=4;
        facecolor='black';
        name=['../results/', 'SAGA', '_',  problem, '_',filename,'tau',num2str(tau),'lambda-5nonuniform'];

        case 'SAGA-UNI'
         mark='s';
        
        color='r';
        facecolor=[.7 .7 .7];
   name=['../results/', 'SAGA', '_',  problem, '_',filename,'tau',num2str(tau),'lambda-5uniform'];

        
    end
    switch tau
        case 10
         lins='-';
    case 50
        lins=':';
          case 1
         lins='--';
        
        
    end
    
  
name
h=dlmread(name);

size(h,1)
size(h,2)


scalep=40;
plotlength=3000;
 switch tau
        case 1
        
        switch method
           case 'SAGA-UNI'
       
         scalep=100;
        
        
        end
 end
 
 switch filename
 
    case 'ijcnn1'
        if(tau<50) 
            scalep=1;
        end
        plotlength=200;
end
    
    px=1:scalep:size(h,1);

    hp=plot(h(px,1),h(px,2));

min(abs(h(:,2)))

h(end,:)
set(gca, 'YScale', 'log');
ylim([0, 1 ]);
xlim([0,plotlength]);

set(hp                           , ...
  'LineStyle'       , lins      , ...
  'Marker'          , mark       , ...
  'Color'           , color , 'LineWidth'       , lw,'MarkerFaceColor' , facecolor );


end

 


end




