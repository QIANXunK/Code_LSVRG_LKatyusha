#ifndef PRIMAL_DUAL_LOOPLESS_SVRG0_H
#define PRIMAL_DUAL_LOOPLESS_SVRG0_H

#include "Primal_Dual_LOOPLESS.h"


#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <sstream>


//This class implements the method loopless SVRG with arbitrary sampling

/*
The optimization problem to solve is:

\sum_{i=1}^n \lambda_i\phi_i(A_i^{\top} w)+ g(w)
Assumption 1: For each i, \phi_i is 1-smooth
By default, lambda_i=1/n for all i.
*
* The dual problem is
*         g*(-sum_{i=1}^n \lambda_i \alpha_i A_i)+\sum_{i=1}^n \lambda_i \phi*_i(\alpha_i)
*/

template<typename L, typename D>
class Primal_Dual_LOOPLESS_SVRG0: public Primal_Dual_LOOPLESS<L, D>
{


private:
   D alpha_l_svrg; //the stepsize parameter alpha in the paper


public:



  virtual inline D gradient_of_phi_i(D, L){return D(NULL);}
  virtual inline D gradient_of_gstar_j(D, L){return D(NULL);}
  virtual inline D value_of_phi_i(D, L) {return D(NULL);}
  virtual inline D value_of_g_j(D, L){return D(NULL);}
  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
  virtual inline D value_of_gstar(vector<D> &){return D(NULL);}
  virtual inline D feasible_dual(vector<D> &){return D(NULL);}
  virtual inline D compute_delta_alpha(D,D,L){return D(NULL);}
  virtual inline void set_auxiliary_v(){}
  virtual inline D get_lambda1(){return D(NULL);}
  virtual inline D get_lambda2(){return D(NULL);}
  virtual inline D compute_just_in_time_prox_grad(D, D, D, L,L){return D(NULL);}


  Primal_Dual_LOOPLESS_SVRG0(const char* matrix_file, const char* vector_file)
  : Primal_Dual_LOOPLESS<L,D>(matrix_file, vector_file)
  {

  }

  Primal_Dual_LOOPLESS_SVRG0(const char* matrix_file)
  : Primal_Dual_LOOPLESS<L,D>(matrix_file)
  {

  }

  inline D compute_current_xj_value(D ui, L j, L t0 , L t1)
  {
    return compute_just_in_time_prox_grad(alpha_l_svrg, ui , this->primal_x[j], t0,t1);
  }

  inline void set_stepsize(){
    alpha_l_svrg=1/(4.*this->L1+2*this->L2);
  }

  inline void update_x(D xj,L j){
    this->primal_x[j]=xj;
  }


 inline void update_baralpha()
  {
    D yi=gsl_rng_uniform(this->rng);
    if(yi<=this->p){
      this->nb_iters+=this->nsamples/this->tau;
      //if(nb_iters%this->nsamples==0){
      D aitg=0;
      D deltaalphai=0;
      for(L i=0;i<this->nsamples;i++)
      {
        aitg=this->compute_AiTxk(i);
        deltaalphai=gradient_of_phi_i(aitg,i)-this->dual_alpha[i];
        this->dual_alpha[i]+=deltaalphai;
        for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
        {
          L j=this->row_idx[k];
          this->baralpha[j]+=this->lambda_f[i]*deltaalphai*this->A[k];
        }
      }
    }
  }


  void loopless_svrg(vector<D> & x0, vector<D> & w0, string filename, D L_phi, D val_mu, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L p_mod, D scal_p)
  {
    filename="SVRG"+filename;
    this->loopless( x0,  w0,  filename,  L_phi,  val_mu,  val_epsilon, max_nb, nb_tau, nb_c, u, p_mod,scal_p);
  }












  };

  #endif /* MIN_SMOOTH_CONVEX_H */
