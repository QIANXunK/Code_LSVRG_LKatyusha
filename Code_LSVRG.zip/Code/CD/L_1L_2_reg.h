#ifndef L_1L_2_REG_H
#define L_1L_2_REG_H


#include "Composite.h"

#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>



// This class solves problem of the form f(x)+g(x) where f(x)=\sum_{j=1}^m lambda_f[j] \phi_j(<A_j,x>)
//and g(x)=\frac{\lambda2}{2}\|x\|^2+\lambda1|x|_1. We all assume that each \phi_j is 1-smooth.

//The default value of lambda_f[i] is val_lambda_f/m for all i\in [m].

template<typename L, typename D>
class L_1L_2_reg: public Composite<L, D>
{
private:
  D lambda1;
  D lambda2;





protected:

public:

  virtual inline D gradient_of_phi_j(D, L){return D(NULL);}

  virtual inline D value_of_phi_j(D, L){return D(NULL);}

  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}


  L_1L_2_reg(const char* matrix_file, D val_lamdba_f)
  : Composite<L,D>(matrix_file, val_lamdba_f){

  }


      inline D value_of_g_i(D x, L i){
        return lambda2*x*x/2+lambda1*fabs(x);
      }



      inline D value_of_gstar(vector<D> & x){

        if(lambda2>0)
        {
          D res=0;
          D ip=0;
          L l=x.size();
          for(L i=0;i<l;i++)
          {
            ip=max(fabs(x[i])-lambda1,0.0);
            res+=ip*ip;
          }
          return res/2/lambda2;
        }
        else
        {
            return 0;
        }
      }

      inline void set_lambda1(D l1){lambda1=l1;}

      inline void set_lambda2(D l2){lambda2=l2;}

      inline D feasible_dual(vector<D> & x){

        if(lambda2>0)
        {
            return 1;
        }
        else
        {
            D scal=1;
            L l=x.size();
            for(L i=0;i<l;i++)
                if(fabs(x[i])>lambda1)
              scal=min(lambda1/fabs(x[i]),scal);
            return scal;
        }
      }

      inline D compute_prox(D x1,D x2,D x3, L i){
        return compute_one_step(1.0/x2, x1, x3)-x3;
      }

      D compute_one_step(D tau, D u, D x){
        D new_x;
        if(x>tau*(lambda1+u))
         new_x=(x-tau*(lambda1+u))/(1+lambda2*tau);
        else if(x<tau*(u-lambda1))
         new_x=(x-tau*(u-lambda1))/(1+lambda2*tau);
        else
         new_x=0;
        return new_x;
      }


      };

      #endif
