#ifndef PRIMAL_DUAL_SAGA_H
#define PRIMAL_DUAL_SAGA_H

#include "problem_data.h"


#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>


//This class implements the method SAGA with arbitrary sampling

/*
The optimization problem to solve is:

\sum_{i=1}^n \lambda_i\phi_i(A_i^{\top} w)+ g(w)
Assumption 1: For each i, \phi_i is 1-smooth
By default, lambda_i=1/n for all i.
*
* The dual problem is
*         g*(-sum_{i=1}^n \lambda_i \alpha_i A_i)+\sum_{i=1}^n \lambda_i \phi*_i(\alpha_i)
*/

template<typename L, typename D>
class Primal_Dual_SAGA: public problem_data<L, D>
{


private:

  // involved variables



  std::vector<D> primal_x;     // the x variable in the paper

  std::vector<D> dual_alpha;  //  the matrix J=[dual_alpha[1]A_1,\dots,dual_alpha[n]A_{nsamples}]

  std::vector<D> lambda_f;    // lambda_f[i]=lambda_i
  std::vector<D> baralpha;   // baralpha=sum_{i=1}^{nsamples} lambda_f[i]* dual_alpha[i]*A_i

  std::vector<D> last_update;

  std::vector<D> proba_vector;

  std::vector<D> sub_proba;


  std::vector<D> gk;     // the vector g^k in the paper
  std::vector<D> last_update_i;

  D alpha_saga; //the stepsize parameter alpha in the paper


  D nb_subset;

  // auxiliary variables
  std::vector<D> deltagk;
  std::vector<D> index_to_do_prox;
  std::vector<D> whether_or_not_to_do_prox;

  L nb_of_iters_per_loop;

  D thetaoverpi;

  D oneminustheta;

  D current_ratio;

  L current_nb_iters;

  D primal_value;

  D dual_value;

  D epsilon;

  L max_nb_loops;

  D max_p;

  D maxv;

  D sumv;

  D sumv1;

  D last_delta;

  D total_w_updated;

  L tau;  //number of threads on each node/computer

  D lambda_1;
  D lambda_2;

  D gradient_norm;

  D running_time;

  L nb_loops;

  L nb_iters;

  L print_every_N;

  D delta;

  vector<L> batch_i;
  vector<L> my_batch;
  vector<D> batch_deltaalphai;

  L batch_size;

  vector<D> dual_alpha_from_x;
  vector<D> baralpha_from_x;
  std::vector<D> sampled;

    ofstream samp;

  std::vector<D> norms;




protected:
  std::vector<D> v;
  D lambdan;

  string uniform;

public:

  int option;
  gsl_rng * rng;
  virtual inline D gradient_of_phi_i(D, L){return D(NULL);}
  virtual inline D gradient_of_gstar_j(D, L){return D(NULL);}
  virtual inline D value_of_phi_i(D, L) {return D(NULL);}
  virtual inline D value_of_g_j(D, L){return D(NULL);}
  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
  virtual inline D value_of_gstar(vector<D> &){return D(NULL);}
  virtual inline D feasible_dual(vector<D> &){return D(NULL);}
  virtual inline D compute_delta_alpha(D,D,L){return D(NULL);}
  virtual inline void set_auxiliary_v(){}
  virtual inline D compute_just_in_time_prox_grad(D, D, D, L,L){return D(NULL);}
  virtual inline D get_lambda1(){return D(NULL);}
  virtual inline D get_lambda2(){return D(NULL);}

  Primal_Dual_SAGA(const char* matrix_file, const char* vector_file)
  : problem_data<L,D>(matrix_file, vector_file)
  {

  }

  Primal_Dual_SAGA(const char* matrix_file)
  : problem_data<L,D>(matrix_file)
  {

  }

  void set_rng()
  {
    gsl_rng_env_setup();
    const gsl_rng_type * T;
    T = gsl_rng_default;
    rng = gsl_rng_alloc(T);
    // gsl_rng_set(rng,time(NULL));
    gsl_rng_set(rng, 27432042);

  }


void set_print_every_N(L i){print_every_N=i;}

  void set_v()
  {
    maxv=0;
    D minv=std::numeric_limits<double>::max();
    v.resize(this->nsamples,0);
    norms.resize(this->nsamples,0);
    sumv=0;
    L sumw=0;
    L maxw=0;
    L minw=this->nsamples;
    sumv1=0;
    for(L j=0;j<this->nfeatures;j++)
    {
      sumw+=this->w[j];
      maxw=max(maxw,this->w[j]);
      minw=min(minw,this->w[j]);
    }
    cout<<"sumw="<<sumw<<";  maxw="<<maxw<<"; minw="<<minw<<endl;
    for(L i=0;i<this->nsamples;i++)
    {
      D vi=0;
      D vi1=0;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        vi+=(1+(this->w[j]-1)*(tau-1.0)/(this->noverc-1.0)+((tau+0.0)/this->noverc-(tau-1.0)/(this->noverc-1.0))*(1.0-1.0/this->wprime[j])*this->w[j])*this->A[k]*this->A[k];
        vi1+=1*this->A[k]*this->A[k];
        if(vi<0){cout<<vi<<" "<<" wprime "<<this->wprime[j]<<endl;break; }
      }
      norms[i]=vi1;
      //if(i%2000==0) cout<<vi/vi1<<" ";
      v[i]=vi;
      //cout<<vi/vi1<<endl;
      sumv+=vi;
      sumv1+=vi1*lambda_f[i];
      if(maxv<vi) maxv=vi;
      if(minv>vi) minv=vi;
    }
    cout<<endl;
    cout<<"  max of v: "<<maxv<<"  min of v: "<<minv<<" sumofv: "<<sumv<<" sumofv1: "<<sumv1<<endl;

    cout<<" ctau/max v_i+nlambdagamma="<<this->c*this->tau*this->lambda*this->gamma/(maxv+this->lambdan*this->gamma)<<endl;
    cout<<"tau(maxi vi+lgn)/(taumaxi vi+lgn)="<<this->tau*(5.36053+this->lambdan*this->gamma)/(maxv+this->lambdan*this->gamma)<<endl;

  }

  void set_v2()
  {
    v.resize(this->nsamples,0);
    for(L i=0;i<this->nsamples;i++)
    {
      D vi=0;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        vi+=(1+this->proba_vector[i]*(this->w[j]-1))*this->A[k]*this->A[k];
      }
      v[i]=vi;
    }
  }

  void set_optimal_probability()
  {
    proba_vector.resize(this->nsamples,0);
    D sum=0;
    for(L i=0; i<this->nsamples;i++)
    {
      proba_vector[i]=3*v[i]*lambda_f[i]+this->mu;
      sum+=proba_vector[i];
    }
    max_p=0;
    for(L i=0; i<this->nsamples;i++)
    {
      proba_vector[i]=proba_vector[i]/sum;
      if(max_p<proba_vector[i])
      max_p=proba_vector[i];
    }
  }

  void set_uniform_probability()
  {
    proba_vector.clear();
    proba_vector.resize(this->nsamples,(tau*this->c+0.0)/this->nsamples);
    max_p=(tau*this->c+0.0)/this->nsamples;
  }


  void set_independent_probability(){
    proba_vector.resize(this->nsamples,0);
    std::vector<D> q(this->nsamples);
    D sumq=0;
    for(L i=0; i<this->nsamples;i++)
    {
      //q[i]=4*v[i]*lambda_f[i]+this->mu;
      q[i]=8*norms[i]*lambda_f[i]+this->mu;
      sumq+=q[i];
    }
    D maxq=0;
    L nb=0;
    D tmp=0;
    for(L i=0; i<this->nsamples;i++)
    {
        q[i]=q[i]/sumq*tau;
        if(q[i]>maxq) maxq=q[i];
        if(q[i]>1) {
          nb++; //count the number of elements larger than 1
          tmp+=q[i]-1;
        }
    }
    if(maxq<=1){
    for(L i=0; i<this->nsamples;i++)
    {
        proba_vector[i]=q[i];
    }
    }else{
     for(L i=0; i<this->nsamples;i++)
    {
      if(q[i]>1) q[i]=1;
      else {
        D deltaq=min(1-q[i],tmp);
        tmp=tmp-deltaq;
        q[i]+=deltaq;
      }
    }
    //for(L i=0; i<this->nsamples;i++)
    //{
    //    proba_vector[i]=q[i]/maxq+(1-q[i]/maxq)*(tau-tau/maxq)/(this->nsamples-tau/maxq);
    //}
    }
  }

  void set_subset_independent_probability(){

    D sumq=0;
    for(L i=0; i<nb_subset;i++)
    {
      sumq+=sub_proba[i];
    }
    D maxq=0;
    for(L i=0; i<nb_subset;i++)
    {
        sub_proba[i]=sub_proba[i]/sumq*tau;
        if(sub_proba[i]>maxq) maxq=sub_proba[i];
    }
    if(maxq>1){
     for(L i=0; i<nb_subset;i++)
    {
        D q=sub_proba[i];
        sub_proba[i]=q/maxq+(1-q/maxq)*(tau-tau/maxq)/(nb_subset-tau/maxq);
    }
    }
  }


  inline L sampling(L n)
  {
    //L i=(floor)(gsl_rng_uniform(rng)*n);
    L i=gsl_rng_uniform_int(rng, n);
    if(this->c==1&&this->tau==1)
    {
      D y=gsl_rng_uniform(rng);
      while(y*max_p>proba_vector[i])
      {
        i=(floor)(gsl_rng_uniform(rng)*n);
        y=gsl_rng_uniform(rng);
      }
    }
    return i;
  }




  void update_baralpha()
  {
    for(L i_t=0;i_t<this->c;i_t++)
    for(L i_bt=0;i_bt<tau;i_bt++)
    {
      L i=batch_i[i_t*tau+i_bt];
      D deltaalphai=batch_deltaalphai[i_t*tau+i_bt];
      dual_alpha[i]+=deltaalphai;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        baralpha[j]+=lambda_f[i]*deltaalphai*this->A[k];
      }
    }
  }


   void update_baralpha_independent_sampling()
  {
    for(L i_t=0;i_t<batch_size;i_t++)
    {
      L i=batch_i[i_t];
      D deltaalphai=batch_deltaalphai[i_t];
      dual_alpha[i]+=deltaalphai;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        baralpha[j]+=lambda_f[i]*deltaalphai*this->A[k];
      }
    }
  }

  void update_primal()
  {
    //compute g^k

    L nb_indices=0;

    for(L i_t=0;i_t<this->c;i_t++)
    for(L i_bt=0;i_bt<tau;i_bt++)
    {
      L i=batch_i[i_t*tau+i_bt];
      D deltaalphai=batch_deltaalphai[i_t*tau+i_bt];

      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
      {
        L j=this->row_idx[k];
        if (whether_or_not_to_do_prox[j]==0) {
          whether_or_not_to_do_prox[j]=1;
          index_to_do_prox[nb_indices]=j;
          nb_indices++;
          deltagk[j]=0;
        }
        deltagk[j]+=lambda_f[i]*deltaalphai*this->A[k]/proba_vector[i];
      }
    }

    for(L i_d=0;i_d<nb_indices;i_d++){
      L j=index_to_do_prox[i_d];
      //cout<<"before: primal_x["<<j<<"]="<<primal_x[j]<<endl;
      primal_x[j]=compute_just_in_time_prox_grad(alpha_saga, baralpha[j]+deltagk[j] , primal_x[j], 0,1);
      //cout<<"after: primal_x["<<j<<"]="<<primal_x[j]<<endl;
      last_update_i[j]=current_nb_iters;
      whether_or_not_to_do_prox[j]=0;
      index_to_do_prox[i_d]=-1;
    }

  }

  void update_baralpha(L  i, D deltaalphai)
  {
    for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
    {
      L j=this->row_idx[k];
      baralpha[j]+=lambda_f[i]*deltaalphai*this->A[k];
    }
  }

  void update_baralpha_from_x(L  i, D deltaalphai)
  {
    for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
    {
      L j=this->row_idx[k];
      baralpha_from_x[j]+=lambda_f[i]*deltaalphai*this->A[k];
    }
  }




  D compute_AiTxk(L i) //This function compute A_i^\top x^k in SAGA (here primal_w is the primal variable x^k in SAGA)
  {
    D res=0;
    for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
    {
      L j=this->row_idx[k];
      if(current_nb_iters!=last_update_i[j])
      {
        primal_x[j]=compute_just_in_time_prox_grad(alpha_saga, baralpha[j] , primal_x[j], last_update_i[j],current_nb_iters);
      }
      res+=this->A[k]*primal_x[j];
      last_update_i[j]=current_nb_iters;
    }
    return res;
  }







  void compute_dual_value()
  {

    D res=0;
    std::vector<D> alpha_tmp(this->nsamples,0);
      std::vector<D> baralpha_tmp(this->nfeatures,0);
      for(L i=0;i<this->nsamples;i++)
      {
        D aitx=compute_AiTxk(i);
        alpha_tmp[i]=gradient_of_phi_i(aitx,i);
        for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
        {
          L j=this->row_idx[k];
          baralpha_tmp[j]+=lambda_f[i]*alpha_tmp[i]*this->A[k];
        }
      }

      for(L j=0; j<this->nfeatures; j++)
      {
        primal_x[j]=compute_just_in_time_prox_grad(alpha_saga, baralpha[j] , primal_x[j], last_update_i[j],current_nb_iters);
        last_update_i[j]=current_nb_iters;
      }

    D scal=feasible_dual(baralpha_tmp);
    for(L i=0;i<this->nsamples;i++)
    {
      res-=value_of_phistar_i(scal*alpha_tmp[i],i)*lambda_f[i];
    }
    res-=value_of_gstar(baralpha_tmp); // should have used value_of_gstar(-baralpha)
    dual_value=res;
  }

  void compute_primal_value()
  {
    //baralpha.clear();
    //baralpha.resize(this->nfeatures,0);
    D res=0;

    for(L i=0;i<this->nsamples;i++)
    {
      D aitx=compute_AiTxk(i);
      //dual_alpha[i]=gradient_of_phi_i(aitx,i);

      //update_baralpha(i, dual_alpha[i]);
      res+=lambda_f[i]*value_of_phi_i(aitx,i);
    }
    D res2=0;
    for(L j=0; j<this->nfeatures; j++)
    {
      primal_x[j]=compute_just_in_time_prox_grad(alpha_saga, baralpha[j] , primal_x[j], last_update_i[j],current_nb_iters);
      last_update_i[j]=current_nb_iters;
      D gj=value_of_g_j(primal_x[j],j);
      res2+=gj;
      }
    primal_value= res+res2;
  }

  void compute_gradient_norm()
  {
    D res=0;
    std::vector<D> baralpha_tmp(this->nfeatures,0);
    for(L i=0;i<this->nsamples;i++)
    {
      D aitx=compute_AiTxk(i);

      D alpha_tmp=gradient_of_phi_i(aitx,i);
      for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
      {
        L j=this->row_idx[k];
        baralpha_tmp[j]+=lambda_f[i]*alpha_tmp*this->A[k];
      }
    }
    for(L j=0; j<this->nfeatures; j++){
    res+=baralpha_tmp[j]*baralpha_tmp[j];
    //cout<<"baralpha_tmp["<<j<<"]="<<baralpha_tmp[j]<<endl;
  }
    for(L j=0; j<this->nfeatures; j++)
    {
      primal_x[j]=compute_just_in_time_prox_grad(alpha_saga, baralpha[j] , primal_x[j], last_update_i[j],current_nb_iters);
      last_update_i[j]=current_nb_iters;
          }
      gradient_norm=sqrt(res)/sumv1;

  }





  void compute_initial_dual_value()
  {

    D res=0;
    D scal=feasible_dual(baralpha);
    for(L i=0;i<this->nsamples;i++)
    {
      res-=value_of_phistar_i(scal*dual_alpha[i],i)*lambda_f[i];
    }
    res-=value_of_gstar(baralpha); // should have used value_of_gstar(-baralpha)
    dual_value=res;
  }


  void compute_initial_primal_value()
  {
    D res=0;
    for(L j=0; j<this->nfeatures; j++)
    {
      //primal_x[j]=gradient_of_gstar_j(-baralpha[j],j);
      res+=value_of_g_j(primal_x[j],j);
    }
    D res2=0;
    for(L i=0;i<this->nsamples;i++)
    {
      D aitx=0;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
      {
        L j=this->row_idx[k];
        aitx+=this->A[k]*primal_x[j];
      }
      res2+=lambda_f[i]*value_of_phi_i(aitx,i);
    }
    primal_value= res+res2;
  }








  void initialize(vector<D> & x0, vector<D> & w0, D L_phi, D val_mu, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
  {
    cout<<"start initializing"<<endl;
    this->distributed_set_up(nb_c);
    cout<<"finish in"<<endl;
    if(nb_tau>this->noverc) perror("tau should be less than n over c");
    tau=nb_tau;
    nb_of_iters_per_loop=floor(this->nsamples/(this->c*(tau+0.0)));
    nb_subset=2*tau;
    if(tau>1 && u==0){
        batch_i.clear();
        batch_i.resize(this->nsamples,0);
        my_batch.resize(nb_subset,0);
        sub_proba.resize(nb_subset,0);
        batch_deltaalphai.clear();
        batch_deltaalphai.resize(this->nsamples,0);
    }
    else
    {
    batch_i.clear();
    batch_deltaalphai.clear();
    batch_i.resize(nb_tau*nb_c);
    batch_deltaalphai.resize(nb_tau*nb_c);
    }
    dual_alpha_from_x.clear();
    dual_alpha_from_x.resize(this->nsamples,0);

    deltagk.resize(this->nfeatures,0);
    index_to_do_prox.resize(this->nfeatures,-1);
    whether_or_not_to_do_prox.resize(this->nfeatures,0);
    gk.clear();
    gk.resize(this->nfeatures,0);

    /**setup parameters**/
    epsilon=val_epsilon;
    max_nb_loops=max_nb;
    this->mu=val_mu;
    lambda_f.resize(this->nsamples,L_phi/this->nsamples); //L_phi is the Lipschitz constant of the function \phi_i.

    set_rng();
    set_auxiliary_v();
    sampled.clear();
    sampled.resize(this->nsamples,0);

    lambda_1=get_lambda1();
    lambda_2=get_lambda2();


    D L_f=compute_lambda_max(10);
    cout<<"L_f="<<L_f<<endl;
    running_time=0;
    set_v();
    /**setup probability**/
    if(tau*this->c>1 && u==1)
    {
      this->set_uniform_probability();
      this->uniform="uniform";

    }
    else if(tau*this->c>1 && u==0){
        this->set_independent_probability();
      this->uniform="nonuniform";
      //set_v2();
    }
    else if(u==1)
    {
      this->set_uniform_probability();
      this->uniform="uniform";
    }
    else if(u==0)
    {
      this->set_optimal_probability();
      this->uniform="nonuniform";
    }
    else if(u==3)
    {

      this->uniform="adaptive";
    }



    primal_x=w0;
    dual_alpha=x0;

    baralpha.clear();
    baralpha.resize(this->nfeatures,0);
    baralpha_from_x.clear();
    baralpha_from_x.resize(this->nfeatures,0);
    last_update_i.clear();
    last_update_i.resize(this->nfeatures,0);

    alpha_saga=1;
    for(L i=0;i<this->nsamples;i++)
    {
      //D st=2*proba_vector[i]/(4*v[i]*lambda_f[i]+this->mu)/3;
      D st=proba_vector[i]/(3*v[i]*lambda_f[i]+this->mu);
      if (alpha_saga>st) alpha_saga=st;
      update_baralpha(i, dual_alpha[i]);

    }

    if(tau*this->c>1 && u==0){
      alpha_saga=1;
        for(L i=0;i<this->nsamples;i++){
           D st=proba_vector[i]/(8*norms[i]*lambda_f[i]*(1-this->proba_vector[i])+this->mu);
         if (alpha_saga>st) alpha_saga=st;
      }
      cout<<alpha_saga<<endl;
     D st=0.25/L_f*this->nsamples;
     cout<<"st="<<st<<endl;
     if (alpha_saga>st) alpha_saga=st;

    }

    //cout<<alpha_saga<<"proba_vector[0]="<<proba_vector[0]<<"; mu="<<mu<<"lambda_f[0]"<<lambda_f[0]<<endl;
    current_nb_iters=0;
    if(lambda_1==0&& lambda_2==0){
      compute_initial_primal_value();
      compute_gradient_norm();
      cout<<"primal_value="<<primal_value<<";  gradient_norm="<<gradient_norm<<endl;
    }else{
    compute_initial_primal_value();
    compute_initial_dual_value();
    compute_gradient_norm();
    cout<<"primal value="<<primal_value<<endl;
    cout<<"dual_value="<<dual_value<<endl;
  }
    cout<<"alpha_saga:"<<alpha_saga<<"; alpha_saga*mu"<<alpha_saga*this->mu<<endl;
    cout<<"finished initializing"<<endl;
  }

  D compute_lambda_max(L K){

    std::vector<D> bk(this->nfeatures);
    for (L j=0;j<this->nfeatures;j++)
      bk[j]=1;
    std::vector<D> yk(this->nsamples);
    D normk;
    D tmp;
    for(L kk=0;kk<K;kk++){
        for (L i=0;i<this->nsamples;i++){
        tmp=0;
        for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
         {
          L j=this->row_idx[k];
          tmp+=this->A[k]*bk[j];
        }
        yk[i]=tmp;
       }
       normk=0;
       for (L j=0;j<this->nfeatures;j++){
         bk[j]=0;
         for (L k = this->ptr_t[j]; k < this->ptr_t[j + 1];	k++)
          {
           L i=this->col_idx[k];
           bk[j]+=this->A_t[k]*yk[i];
         }
         normk+=bk[j]*bk[j];
    }
    normk=sqrt(normk);
    for (L j=0;j<this->nfeatures;j++)
      {bk[j]=bk[j]/normk; }
  }
  cout<<endl;
  D res=0;
  normk=0;
  for (L i=0;i<this->nsamples;i++){
    tmp=0;
  for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
   {
    L j=this->row_idx[k];
    tmp+=this->A[k]*bk[j];
  }
  yk[i]=tmp;
  normk+=yk[i]*yk[i];
 }
   std::vector<D> bk2(this->nfeatures);
 for (L j=0;j<this->nfeatures;j++){
   bk2[j]=0;
   for (L k = this->ptr_t[j]; k < this->ptr_t[j + 1];	k++)
    {
     L i=this->col_idx[k];
     bk2[j]+=this->A_t[k]*yk[i];
   }
 }
  for (L j=0;j<this->nfeatures;j++)
  res+=bk2[j]*bk[j];
  return res;


  }


  void result_record()
  {
    cout<<primal_value<<endl;
    cout<<dual_value<<endl;
    cout<<primal_x[0]<<" ;"<<"dual: "<<dual_alpha[0]<<endl;
    ofstream result;
    result.open("results/x0.dat");
    for (L j=0;j<this->nfeatures;j++){
    //result <<setprecision(20)<< primal_x[j] << " ";
    cout<< primal_x[j] << " ";
  }
    result << endl;
    ofstream resulta;
    resulta.open("results/alpha0.dat");
    for (L i=0;i<this->nsamples;i++)
    resulta << setprecision(20)<<dual_alpha[i] << " ";
    resulta << endl;
    result.close();
  }


  void read_w0(){
    ifstream recordw0("results/x0.dat");
    for(L j=0;j<this->nfeatures;j++)
    {
      recordw0>>primal_x[j];
    }
    recordw0.close();

    ifstream recordalpha0("results/alpha0.dat");
    for(L i=0;i<this->nsamples;i++)
    {
      recordalpha0>>dual_alpha[i];
    }
    recordalpha0.close();

  }







  void compute_and_record_result()
  {
     if(nb_loops%print_every_N==0){
      if(lambda_1==0&& lambda_2==0){
        compute_primal_value();
        compute_gradient_norm();
        delta=gradient_norm;
        cout<<setprecision(9)<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<";  "<<running_time<<"; gradient norm="<<delta<<" primal value="<<primal_value<<endl;
         samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<" "<<running_time<<" "<<primal_value<<endl;
      }else{
      compute_primal_value();
      compute_dual_value();

      delta=primal_value-dual_value;
      cout<<setprecision(9)<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<";  "<<running_time<<"; primal dual gap="<<delta<<" primal value="<<primal_value<<"; dual value="<<dual_value<<endl;
       samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<" "<<running_time<<" "<<primal_value<<endl;

    }
  }

  }




  void batch_sampling()
  {
      L i=sampling(this->nsamples);
      for(L it_b=0;it_b<this->c;it_b++)
      for(L it_t=0;it_t<tau;it_t++)
      {
          while(sampled[i]==1)
           {
             i=sampling(this->nsamples);
           }
          sampled[i]=1;
          batch_i[it_b*tau+it_t]=i;
      }
      for(L it_b=0;it_b<this->c;it_b++)
      for(L it_t=0;it_t<tau;it_t++)
      {
          sampled[batch_i[it_b*tau+it_t]]=0;
      }
  }

  void batch_independent_sampling(){
       //cout<<"nb_subset="<<nb_subset<<"; "<<endl;;

      L i=sampling(this->nsamples);
       //cout<<"it"<<endl;
      for(L it_b=0;it_b<nb_subset;it_b++)
      {
          //cout<<it_b<<endl;
          while(sampled[i]==1)
           {
             i=sampling(this->nsamples);
           }
          sampled[i]=1;
          my_batch[it_b]=i;
          sub_proba[it_b]=proba_vector[i];
          //cout<<"it_b="<<it_b<<"; i="<<i<<"; ";
      }
      //cout<<"hh"<<endl;
      set_subset_independent_probability();
      //cout<<"??"<<endl;
      L bpt=0;
      batch_size=0;
      for(L it_b=0;it_b<nb_subset;it_b++)
      {
          i=my_batch[it_b];
          sampled[i]=0;
          //cout<<"it-b="<<it_b<<"; i="<<i<<"; sub_proba="<<sub_proba[it_b]<<" ";
          D y=gsl_rng_uniform(rng);
          //cout<<"y="<<y<<endl;
          if(y<=sub_proba[it_b]){
              batch_i[bpt]=i;
              batch_size++;
              bpt++;
              //cout<<"sampling it_b="<<it_b<<"; i="<<i<<" ";
          }
      }
      //cout<<endl;

  }

  void SAGA(vector<D> & x0, vector<D> & w0, string filename, D L_phi, D val_mu, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
  {
    initialize(x0,  w0,  L_phi, val_mu, val_epsilon,  max_nb,  nb_tau, nb_c,  u, agg);

    string sampname="results/SAGA_"+filename+uniform;
    cout<<"running SAGA"<<" ; "<<sampname<<endl;
    samp.open(sampname.c_str());


    if(lambda_1==0&& lambda_2==0)
      delta=gradient_norm;
    else
     delta=primal_value-dual_value;
    nb_loops=0;
    nb_iters=0;

    cout<<setprecision(9)<<"initial: "<<" delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
    samp<<((0.0+nb_iters)*this->c*tau/(this->nsamples))<<" "<<delta<<endl;
    //srand48(27432042);
    srand48(time(NULL));


    D start;

    while(delta>=epsilon && nb_loops<max_nb_loops)
    {
      compute_and_record_result();
      start = std::clock();

      nb_loops++;

      //cout<<"before the loop time elapsed="<<duration<<endl;
      start = std::clock();
       //cout<<"nb_of_iters_per_loop="<<nb_of_iters_per_loop<<endl;
      for(L it=0;it<nb_of_iters_per_loop;it++)
      {
          if(tau>1&& u==0){
              batch_independent_sampling();
               for(L it_b=0;it_b<batch_size;it_b++)
               {

                 L i=batch_i[it_b];

                  D aitg=compute_AiTxk(i);
                  D deltaalphai=(gradient_of_phi_i(aitg,i)-dual_alpha[i]);

                   batch_deltaalphai[it_b]=deltaalphai;
              }
               current_nb_iters++;
               update_primal();
              update_baralpha_independent_sampling();
          }
          else{
               batch_sampling();
               for(L it_b=0;it_b<this->c;it_b++)
               for(L it_t=0;it_t<tau;it_t++)
               {

                 L i=batch_i[it_b*tau+it_t];

                  D aitg=compute_AiTxk(i);
                  D deltaalphai=(gradient_of_phi_i(aitg,i)-dual_alpha[i]);

                   batch_deltaalphai[it_b*tau+it_t]=deltaalphai;
               }

              current_nb_iters++;
              update_primal();
              update_baralpha();
          }
        nb_iters++;
      if(delta<epsilon) break;
    }  running_time+= ( std::clock() - start ) / (double) CLOCKS_PER_SEC;
      //cout<<"after the loop time elapsed="<<duration<<endl;
  }
  cout<<setprecision(9)<<"nb_loops: "<<floor(((0.0+nb_iters)*this->c*tau/(this->nsamples)))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
  samp.close();
}









};

#endif /* MIN_SMOOTH_CONVEX_H */
