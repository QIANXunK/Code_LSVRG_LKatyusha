#ifndef Primal_Dual_Acc_H
#define Primal_Dual_Acc_H


#include "problem_data.h"


#include <string>
#include <gsl/gsl_rng.h>
 #include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>


//This class implements the method SPDC for squared l2 norm penalty









template<typename L, typename D>
class Primal_Dual_Acc: public problem_data<L, D>
{
  
  
  private:
   
  // involved variables
  
  
  
  std::vector<D> primal_w;   // the vector x in the paper
  
  std::vector<D> dual_alpha;  // the vector y/n in the paper
  

  
  std::vector<D> u; // the vecto $u$ in the paper
  
  std::vector<D> barx; // the vector $\bar x$ in the paper
  
  std::vector<D> last_ratio;   // (1+\lambda\tau)^{t_0}
  
  std::vector<L> last_t;     //t_0 in Section 5.1 of the paper
  
  std::vector<D> proba_vector;
  
  
  
  
  
  vector<D> ystar;
  vector<D> xstar;
  
  
  D theta;
  

  
  
  D onepluslambdatau;   // =1+lamba*tau in the paper where tau is the parameter in the Algorithm
  
  
  // auxiliary variables
  
  L nb_of_iters_per_loop;
  
 
  
  L current_nb_iters;  // t_1
  
  D current_ratio;  // (1+\lambda\tau)^{t_1}
  
  D primal_value;
  
  D dual_value;
  
  D epsilon; 
  
  L max_nb_loops;
  
  D max_p;
  
  D maxv;
  
  D sumv;
  
  D last_delta;
  
  D total_w_updated;
  
  L m;  //the mini-batch size $m$ in the paper, equal to tau*c here.
  
  L n;  // number of samples
  
  L d;   // number of features
  
  L tau;
  
  D tauinSPDC;  //the tau in the paper
  
  
  D lambdatau; // equal to $\lambda\tau$ in the paper
  
  
  
  D R;
  
  D primal_star;
  
  vector<L> batch_i;
  vector<D> batch_deltaalphai;
 
  
  
  
  std::vector<D> norms;
  
  
  
  
  protected:
   std::vector<D> v;
   D lambdan;
   
   D sigmainSPDC;
   
   string uniform;
  
  public:
    
    int option;
    gsl_rng * rng; 
    virtual inline D gradient_of_phi_i(D, L){return D(NULL);}
    virtual inline D gradient_of_gstar_j(D, L){return D(NULL);}
    virtual inline D value_of_phi_i(D, L) {return D(NULL);}
    virtual inline D value_of_g_j(D, L){return D(NULL);}
    virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
    virtual inline D value_of_gstar(vector<D> &){return D(NULL);}
    virtual inline D compute_delta_alpha(D,D,L){return D(NULL);}
    virtual inline void set_auxiliary_v(){}
    
    
 
    
   Primal_Dual_Acc(const char* matrix_file, const char* vector_file)
   : problem_data<L,D>(matrix_file, vector_file)
   {
      
   }
    
   Primal_Dual_Acc(const char* matrix_file)
   : problem_data<L,D>(matrix_file)
   {
      
   }
    
   void set_rng()
   {
     gsl_rng_env_setup();
     const gsl_rng_type * T; 
     T = gsl_rng_default;
     rng = gsl_rng_alloc(T);
      gsl_rng_set(rng,time(NULL));
   }
   
   
  
  void compute_R()
  {
   
    v.resize(n);
    R=0;
    for(L i=0;i<n;i++)
     {
      D vi=0;
      for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) 
      {
        vi+=1*this->A[k]*this->A[k];
      }
      v[i]=vi;
      if(R<vi) R=vi;
     }
     R=sqrt(R);
  }
  
  
   
  
   void set_optimal_probability()
   {
     proba_vector.resize(n,0);
     D sum=0;
     for(L i=0; i<n;i++)
     {
       proba_vector[i]=v[i]/(0.0+lambdan*this->gamma)+1;
       sum+=proba_vector[i];
     }
     max_p=0;
     for(L i=0; i<n;i++)
     {
       proba_vector[i]=proba_vector[i]/sum;
       if(max_p<proba_vector[i]) 
	 max_p=proba_vector[i];
     }
     theta=lambdan*this->gamma/(sumv+this->gamma*lambdan*n);
     cout<<"optimal proba theta: "<<theta<<endl;
     cout<<"uniform theta: "<<lambdan*this->gamma/(maxv*n+this->gamma*lambdan*n);
   } 
  
   void set_uniform_probability()
   {
     proba_vector.clear();
     proba_vector.resize(n,(tau*this->c+0.0)/n);
     max_p=(tau*this->c+0.0)/n;
   }
  
 
   
    
    inline L sampling(L n)
   {
     //L i=(floor)(gsl_rng_uniform(rng)*n);
     L i=gsl_rng_uniform_int(rng, n);
     /*if(this->c==1&&this->tau==1)
     {
       D y=gsl_rng_uniform(rng);
       while(y*max_p>proba_vector[i])
       {
        i=(floor)(gsl_rng_uniform(rng)*n);
        y=gsl_rng_uniform(rng);
       }
     }*/
     return i;
   }


   void update_dual_variables()
   {
       vector<L> did_we_update_j(this->nfeatures,1);
       for(L i_t=0;i_t<this->c;i_t++)
         for(L i_bt=0;i_bt<tau;i_bt++)
         {
           L i=batch_i[i_t*tau+i_bt];
           D deltaalphai=batch_deltaalphai[i_t*tau+i_bt];
	   dual_alpha[i]+=deltaalphai;
           for (L k = this->ptr[i]; k < this->ptr[i + 1];k++) 
           {
	     L j=this->row_idx[k];
	     L dj=did_we_update_j[j];
	     D deltau=deltaalphai*this->A[k]/m;
	     barx[j]=(1-dj)*barx[j]+dj*(((1+theta)/onepluslambdatau-theta)*primal_w[j]-tauinSPDC/onepluslambdatau*(1+theta)*u[j]/n)-tauinSPDC/onepluslambdatau*(1+theta)*deltau;
	     primal_w[j]=primal_w[j]+dj*(1/onepluslambdatau-1)*primal_w[j]-dj*tauinSPDC/onepluslambdatau*u[j]/n-tauinSPDC/onepluslambdatau*deltau;
	     u[j]+=deltaalphai*this->A[k];    // deltaalphai=(y_{i}^{t+1}-y_i^t)                     
	     did_we_update_j[j]=0;
           }
         }
   }
   
   void update_u(L  i, D deltaalphai)
   {
     for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++) 
     {
       L j=this->row_idx[k];
       u[j]+=deltaalphai*this->A[k];
     }
   }
    
   D compute_AiT_barx(L i)
   {
     D res=0; 
     for(L k = this->ptr[i]; k < this->ptr[i + 1];k++) 
     {
       L j=this->row_idx[k];
       L t1=current_nb_iters;
       L t0=last_t[j];
       D barxj=barx[j];
       if(t1>t0+1)
       {
	 D xjt0_1=primal_w[j];
         D ujt0_1=u[j]/n;
         D xjt1;
	 D p=current_ratio/last_ratio[j]/onepluslambdatau;
	 xjt1=1.0/p*xjt0_1+(1.0/p-1)*ujt0_1/this->lambda;
	 primal_w[j]=xjt1;
	 D xjt1minus1=1.0/p/onepluslambdatau*xjt0_1+(1.0/p/onepluslambdatau-1)*ujt0_1/this->lambda;
	 barxj=xjt1+theta*(xjt1-xjt1minus1);
       }
       res+=this->A[k]*barxj;
       last_t[j]=current_nb_iters;
       last_ratio[j]=current_ratio;
     }
     
     return res;
   }
   
  
   D compute_AiTx(L i)
   {
     D res=0; 
     for(L k = this->ptr[i]; k < this->ptr[i + 1];k++) 
     {
       L j=this->row_idx[k];
  
       L t1=current_nb_iters;
       L t0=last_t[j];
       
       if(t1>t0)
       {
	 D xjt0_1=primal_w[j];
         D ujt0_1=u[j]/n;
         D xjt1;
	 D p=current_ratio/last_ratio[j];
	 xjt1=1/p*xjt0_1+(1/p-1)*ujt0_1/this->lambda;
	 primal_w[j]=xjt1;
	 D xjt1minus1=1/p/onepluslambdatau*xjt0_1+(1/p/onepluslambdatau-1)*ujt0_1/this->lambda;
	 barx[j]=xjt1+theta*(xjt1-xjt1minus1);
       }
       res+=this->A[k]*primal_w[j];
       last_t[j]=current_nb_iters;
       last_ratio[j]=current_ratio;
     }
     return res;
   }
  
    
 
 
    
   void compute_dual_value()
   {
     D res=0;
     for(L i=0;i<n;i++)
     {
       res-=value_of_phistar_i(dual_alpha[i],i);
     }
     res=res/(n+0.0);
     //cout<<"r1: "<<res<<endl;
     res-=1.0/this->lambda*value_of_gstar(u)/(n*n);
     dual_value= res;
   }
   
   void compute_primal_value()
   {
     D res=0;
     for(L i=0;i<n;i++)
     {
       D aitw=compute_AiTx( i);
       res+=value_of_phi_i(aitw,i);
     } 
     res=res/n;
     
     //cout<<"res: "<<res<<endl;
     
     D res2=0;
     for(L j=0; j<this->nfeatures; j++)
     {
       
       L t1=current_nb_iters;
       L t0=last_t[j];
       
       if(t1>t0)
       {
	 D xjt0_1=primal_w[j];
         D ujt0_1=u[j]/n;
         D xjt1;
	 D p=current_ratio/last_ratio[j];
	 xjt1=1/p*xjt0_1+(1/p-1)*ujt0_1/this->lambda;
	 primal_w[j]=xjt1;
	 D xjt1minus1=1/p/onepluslambdatau*xjt0_1+(1/p/onepluslambdatau-1)*ujt0_1/this->lambda;
	 barx[j]=xjt1+theta*(xjt1-xjt1minus1);
       }
       last_t[j]=current_nb_iters;
       last_ratio[j]=1.0;
       D gj=value_of_g_j(primal_w[j],j);
       res2+=gj;
     }
     current_ratio=1.0;
     primal_value= res+res2*this->lambda;
   }
   
   
  
    
   void compute_initial_primal_value()
   {
     D res=0;
     for(L j=0; j<this->nfeatures; j++)
     {
       primal_w[j]=gradient_of_gstar_j(u[j]/n,j)/this->lambda;
       D gj=value_of_g_j(primal_w[j],j);
       res+=this->lambda*gj;
     }
     //cout<<"first res"<<res<<endl;
     D res2=0;
     for(L i=0;i<n;i++)
     {
       D aitw=0;
       for (L k = this->ptr[i]; k < this->ptr[i + 1];	k++)
       {
	 L j=this->row_idx[k];
	 aitw+=this->A[k]*primal_w[j];
       }  
       res2+=value_of_phi_i(aitw,i);
     }
     //cout<<"second res"<<res2<<endl;
     res=res+res2/n;
     primal_value= res;
   }
   
   
  
   
   
   
   
   void initialize(vector<D> & x0, vector<D> & w0, D val_lambda, D val_gamma, D val_epsilon, L max_nb, L nb_tau, L nb_c, L uni, L agg)
   {
     n=this->nsamples;
     d=this->nfeatures;
     cout<<"start itializing"<<endl;
     this->distributed_set_up(nb_c);
    
     if(nb_tau>this->noverc) perror("tau should be less than n over c");
     tau=nb_tau;
     nb_of_iters_per_loop=floor(n/(this->c*(tau+0.0)));
     
     //nb_of_iters_per_loop=1;
     
     batch_i.clear();
     batch_deltaalphai.clear();
     batch_i.resize(nb_tau*nb_c);
     batch_deltaalphai.resize(nb_tau*nb_c);
     
    
     /**setup parameters**/
     m=nb_tau*nb_c;
     this->set_lambda_and_gamma(val_lambda, val_gamma);
     epsilon=val_epsilon;
     max_nb_loops=max_nb;
    
     compute_R();
     
     cout<<"R: "<<R<<endl;
     
     theta=1-1.0/(n/m+R*sqrt(n)/sqrt(m*this->lambda*this->gamma));
     sigmainSPDC=0.5/R*sqrt(n*this->lambda)/sqrt(m*this->gamma);
     tauinSPDC=0.5/R*sqrt(m*this->gamma)/sqrt(n*this->lambda);
     lambdatau=0.5/R*sqrt(m*this->gamma*this->lambda)/sqrt(n);
     onepluslambdatau=1.0+lambdatau;
     
     cout<<"sigmainSPDC: "<<sigmainSPDC<<endl;
     cout<<"tauinSPDC: "<<tauinSPDC<<endl;
     cout<<"lambdatau: "<<lambdatau<<endl;
     cout<<"m: "<<m<<endl;
     
    
     set_auxiliary_v();
     set_rng();
     /** ********************* **/
   
        /**setup probability**/
     if(tau*this->c>1) 
     {
       this->set_uniform_probability();
       this->uniform="uniform";
     }
     else if(uni==1)
     {
       this->set_uniform_probability();
       this->uniform="uniform";
     }
     else if(uni==0)
     {
       
       this->set_optimal_probability();
       this->uniform="nonuniform";
     }
   
      /** ********************* **/
    
        /** Initialize **/
     primal_w=w0;
     dual_alpha=x0;
     
     
     /*
     ifstream readxstar("results/x0");
      for (L j = 0; j < d; j++)  
        readxstar >>primal_w[j];
      ifstream readystar("results/y0");
      for (L i = 0; i < n; i++)  
        {
	  readystar >>dual_alpha[i];
          dual_alpha[i]=dual_alpha[i]/n;
        }
     */
     
     
     u.clear();
     u.resize(this->nfeatures,0);
     last_t.clear();
     last_t.resize(this->nfeatures,0);
     last_ratio.clear();
     last_ratio.resize(this->nfeatures,1.0);
     for(L i=0;i<n;i++)
     {
       update_u(i, dual_alpha[i]);
     }
     
   
     current_nb_iters=0;
     current_ratio=1.0;
     compute_initial_primal_value();
     compute_dual_value();
     barx.resize(d);
     for(L j=0;j<d;j++)
     {
       barx[j]=primal_w[j];
     }
     cout<<"finished itializing"<<endl;
     compute_bound(1e-10);
     cout<<"first distance; "<<compute_distance()<<endl;
   }
    

   void result_record()
   {
     ofstream samp, samp2,samp3;
     samp.open("results/w");
     for(L j=0;j<this->nfeatures;j++)
      {
	samp<<setprecision(20)<<primal_w[j]<<endl;
      }
      samp2.open("results/alpha");
      for(L i=0;i<this->nsamples;i++)
      {
	samp2<<setprecision(20)<<dual_alpha[i]<<endl;
      }
      samp3.open("results/primal_objective");
     samp3<<setprecision(20)<<primal_value<<endl;
   }
   
   
   
    void x0_y0_record()
   {
     ofstream samp, samp2;
     samp.open("results/x0");
     for(L j=0;j<this->nfeatures;j++)
      {
	samp<<setprecision(20)<<primal_w[j]<<endl;
      }
      samp2.open("results/y0");
      for(L i=0;i<this->nsamples;i++)
      {
	samp2<<setprecision(20)<<dual_alpha[i]<<endl;
      }
      
   }
   
   void compute_bound(D epsi)
   {
     xstar.resize(d);
     ystar.resize(n);
     ifstream readxstar("results/w");
      for (L j = 0; j < d; j++)  
        readxstar >>xstar[j];
      ifstream readystar("results/alpha");
      for (L i = 0; i < n; i++)  
        readystar >>ystar[i];
      D C=0;
      D h=(0.5/sigmainSPDC+this->gamma)/(0.5/tauinSPDC+this->lambda)/m;
      for (L j=0; j<d;j++)
	C+=(primal_w[j]-xstar[j])*(primal_w[j]-xstar[j]);
      for (L i = 0; i < n; i++) 
	C+=(dual_alpha[i]-ystar[i])*(dual_alpha[i]*n-ystar[i])*h;
      cout<<"C "<<C<<endl;
      D upper_bound=(n/m+R*sqrt((n+0.0)/(m*this->lambda*this->gamma)))*log(C*(1+1.0/this->gamma)/epsi/epsi);
      cout<<"upper_bound="<<upper_bound/n*m<<endl;
       ifstream readprimalobjective("results/primal_objective");
      readprimalobjective>>primal_star;
   }
    
 
  void compute_norm()
  {
    D xnorm=0;
    for(L j=0;j<d;j++)
      xnorm+=primal_w[j]*primal_w[j];
    cout<<"xnorm: "<<xnorm<<endl;
    D ynorm=0;
    for(L i=0;i<n;i++)
      ynorm+=dual_alpha[i]*dual_alpha[i];
    cout<<"ynorm: "<<ynorm<<endl;
  }
   
   
  D compute_distance()
  {
    D dis=0;
    D c1=0.5/tauinSPDC+this->lambda;
    D c2=0.25/sigmainSPDC+this->gamma/m;
    for(L j=0;j<d;j++)
      dis+=c1*(primal_w[j]-xstar[j])*(primal_w[j]-xstar[j]);
    for(L i=0;i<n;i++)
      dis+=c2*(dual_alpha[i]-ystar[i])*(dual_alpha[i]-ystar[i]);
    return dis;
  }
   
   
    
   void SPDC(vector<D> & x0, vector<D> & w0, string filename, D val_lambda, D val_gamma, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L agg)
   {
     initialize(x0,  w0,  val_lambda, val_gamma, val_epsilon,  max_nb,  nb_tau, nb_c,  u, agg);
     cout<<"*************"<<"running SPDC"<<" : "<<filename<<"*************"<<endl;
     string sampname="results/SPDC_"+filename+uniform;
     ofstream samp;
     samp.open(sampname.c_str());
     
     
     
     cout<<"theta="<<theta<<endl;
     string thetafilename="/data/zqu/theta"+filename+uniform;
     ofstream thetafile;
     thetafile.open(thetafilename.c_str());
     thetafile<<theta<<endl;
     
     
     D delta=primal_value-dual_value; 
     L nb_loops=0;
     L nb_iters=0;
 
     cout<<setprecision(9)<<"initial: "<<" delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
     samp<<((0.0+nb_iters)*this->c*tau/(n))<<" "<<delta<<endl;
     srand48(27432042);
     L * order = this->new_order(this->noverc,this->c);
     ofstream samplingpts;
     samplingpts.open("results/sampling");
     ofstream dalphaf;
     dalphaf.open("results/deltaalpha");
     while(delta>=epsilon && nb_loops<max_nb_loops)
     {
       this->permutation(order,this->noverc,this->c);
      
       nb_loops++;
       
       for(L it=0;it<nb_of_iters_per_loop;it++)
       {
	 current_ratio*=onepluslambdatau;
	 current_nb_iters++;
	 total_w_updated=0;
	 //vector<L> sampled(this->nsamples);
	 for(L it_b=0;it_b<this->c;it_b++)
	   for(L it_t=0;it_t<tau;it_t++)
	   {
	     //L i=order[it_b*this->noverc+it*tau+it_t];
	     //i=this->index_of_samples[it_b*this->noverc+i];
	     //L i=sampling(n);
	    
	     L i=sampling(this->nsamples);
		//while(sampled[i]==1)
		//{
		  //i=sampling(this->nsamples);
		//}
	     //sampled[i]=1;
	     //samplingpts<<proba_vector[i]<<endl;
	     D aitbarx=compute_AiT_barx(i);
	     
	     //cout<<"aitbarx: "<<aitbarx<<endl;
	     
	     D deltaalphai=compute_delta_alpha(dual_alpha[i], aitbarx, i);
	     //if(nb_iters%1000==0) cout<<setprecision(15)<<"deltaalphai: "<<deltaalphai<<endl;
	     
	     //cout<<"r2: "<<-value_of_phistar_i(deltaalphai*n,  i)/n<<endl;
	     
	     //D delta_dual_value=-value_of_phistar_i(deltaalphai*n,  i)/n-v[i]*deltaalphai*deltaalphai/(2*this->lambda);
	     //cout<<"delta_dual_value: "<< delta_dual_value<<endl;
	     dalphaf<<deltaalphai<<endl;
	     batch_i[it_b*tau+it_t]=i;
	     batch_deltaalphai[it_b*tau+it_t]=deltaalphai;
	    }
	  update_dual_variables();
	  nb_iters++;
	
	  /*
	  if( (nb_iters*this->c*tau)%((int)(this->nsamples/5.0))==0)
	  {
	    compute_primal_value();
	    compute_dual_value();
	    delta=primal_value-dual_value;
	    samp<<((0.0+nb_iters)*this->c*tau/(n))<<" "<<delta<<endl;
	    cout<<setprecision(15)<<"nb of epochs: "<<((0.0+nb_iters)*this->c*tau/(n))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;

	  }
	  */
	  if(delta<epsilon) break;
        }
	compute_primal_value();
	compute_dual_value();
	delta=primal_value-dual_value;
	samp<<((0.0+nb_iters)*this->c*tau/(n))<<" "<<delta<<endl;
	if(delta<=epsilon) samp<<((0.0+nb_iters)*this->c*tau/(n))<<" "<<delta<<endl;
	cout<<setprecision(15)<<"nb of epochs: "<<((0.0+nb_iters)*this->c*tau/(n))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
     }
     cout<<setprecision(9)<<"nb_loops: "<<floor(((0.0+nb_iters)*this->c*tau/(n)))<<";  delta: "<<delta<<" primal: "<<primal_value<<"; dual: "<<dual_value<<endl;
     result_record();
     //x0_y0_record();
     //compute_norm();
   }
   
    
    
    
    
    
   
   
  
};

#endif 
