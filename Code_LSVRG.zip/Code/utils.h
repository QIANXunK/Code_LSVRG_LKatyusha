

#ifndef UTILS_H_
#define UTILS_H_

#include <sys/time.h>


double gettime_(void) {
	struct timeval timer;
	if (gettimeofday(&timer, NULL))
		return -1.0;
	return timer.tv_sec + 1.0e-6 * timer.tv_usec;
}

template <typename T> int sgn(T val)
{
    return (val > T(0)) - (val < T(0));
}

int my_power (int number, int index) {
    if (index == 0) {
        return 1;
    }
    int num = number;
    for (int i = 1; i < index; i++) {
        number = number * num;
    }
    return number;
}


#endif /* UTILS_H_ */
