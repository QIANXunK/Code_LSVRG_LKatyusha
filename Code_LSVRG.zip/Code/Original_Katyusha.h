#ifndef ORIGINAL_KATYUSHA_H
#define ORIGINAL_KATYUSHA_H

#include "Primal_Dual_LOOPLESS.h"


#include <string>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <stdio.h>      /* printf */
#include <time.h>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <sstream>


//This class implements the method loopless kATYUSHA with arbitrary sampling

/*
The optimization problem to solve is:

\sum_{i=1}^n \lambda_i\phi_i(A_i^{\top} w)+ g(w)
Assumption 1: For each i, \phi_i is 1-smooth
By default, lambda_i=1/n for all i.
*
* The dual problem is
*         g*(-sum_{i=1}^n \lambda_i \alpha_i A_i)+\sum_{i=1}^n \lambda_i \phi*_i(\alpha_i)
*/

template<typename L, typename D>
class Original_Katyusha: public Primal_Dual_LOOPLESS<L, D>
{


protected:
   D theta1;
   D theta2;
   D theta3;
   D eta; //the stepsize parameter alpha in the paper

   D x;
   D w;
   D y;
   D z;

   D beta;    //beta=1/(1+min(alpha*sigma,1/4/m))

   D tilde_xj;

   std::vector<D> primal_y;     // the y variable

   std::vector<D> primal_z;     // the z variable

   std::vector<D> primal_w;     // equal to tilde_x

   std::vector<D> tilde_x;     // the tilde_x variable
  L m;

public:


  virtual inline D gradient_of_phi_i(D, L){return D(NULL);}
  virtual inline D gradient_of_gstar_j(D, L){return D(NULL);}
  virtual inline D value_of_phi_i(D, L) {return D(NULL);}
  virtual inline D value_of_g_j(D, L){return D(NULL);}
  virtual inline D value_of_phistar_i(D,L) {return D(NULL);}
  virtual inline D value_of_gstar(vector<D> &){return D(NULL);}
  virtual inline D feasible_dual(vector<D> &){return D(NULL);}
  virtual inline D compute_delta_alpha(D,D,L){return D(NULL);}
  virtual inline void set_auxiliary_v(){}
  virtual inline D get_lambda1(){return D(NULL);}
  virtual inline D get_lambda2(){return D(NULL);}
  virtual inline void compute_just_in_time_prox_grad(D, D, D &, L,L, D, D &, D &){}


  Original_Katyusha(const char* matrix_file, const char* vector_file)
  : Primal_Dual_LOOPLESS<L,D>(matrix_file, vector_file)
  {

  }

  Original_Katyusha(const char* matrix_file)
  : Primal_Dual_LOOPLESS<L,D>(matrix_file)
  {

  }


  void set_theta(){
    m=ceil(this->nsamples/this->tau/this->scaler);
    D barL=this->sumLi/this->nsamples;
    D barLoverb=barL/this->tau;
    theta2=min(barLoverb/this->Lf,1.)/2;
    D L_s;
    if(this->Lf<= barLoverb*m){
      D tmp=8*this->tau*m*this->mu/3/barL/3;
      if(tmp>=1){
        theta1=theta2;
      }
      else{
        theta1=sqrt(tmp)*theta2;
      }
      L_s=barLoverb/2/theta2;
    }else
    {
      theta1=min(sqrt(2*this->mu/3/this->Lf),0.5/m);
     L_s=this->Lf;
    }
    theta3=1-theta1-theta2;
    eta=1./theta1/3./L_s;
    beta=max(1./(1.+(eta*this->mu)),1./(1.+(1/4./m)));
    cout<<"; theta1="<<theta1<<"; theta2="<<theta2<<"; theta3="<<theta3<<" beta="<<beta<<endl;
    cout<<"eta="<<eta<<endl;
  }

  inline D compute_current_xj_value(D ui, L j, L t0 , L t1)
  {
    w=primal_w[j];
    y=primal_y[j];
    z=primal_z[j];
    tilde_xj=tilde_x[j];
    compute_just_in_time_prox_grad(eta, ui , z, t0, t1, w, y, tilde_xj);
    x=theta1*z+theta2*w+theta3*y;
    return x;
  }

  inline void set_stepsize(){
    primal_y.clear();
    primal_z.clear();
    primal_w.clear();
    tilde_x.clear();
    primal_y.resize(this->nfeatures,0);
    primal_z.resize(this->nfeatures,0);
    primal_w.resize(this->nfeatures,0);
    tilde_x.resize(this->nfeatures,0);
    for(L j=0; j<this->nfeatures; j++){
      primal_y[j]=this->primal_x[j];
      primal_z[j]=this->primal_x[j];
      primal_w[j]=this->primal_x[j];
    }
    set_theta();
  }

  inline void update_x(D xj,L j){
    this->primal_x[j]=xj;
    primal_z[j]=z;
    primal_y[j]=y;
    tilde_x[j]=tilde_xj;
  }


  inline void update_baralpha()
   {
     if(this->current_nb_iters%m==0){
         this->nb_iters+=this->nsamples/this->tau;
         D aitg=0;
         D deltaalphai=0;
         for(L i=0;i<this->nsamples;i++)
         {
           aitg=compute_AiT_tildex(i);
           deltaalphai=gradient_of_phi_i(aitg,i)-this->dual_alpha[i];
           this->dual_alpha[i]+=deltaalphai;
           for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
           {
             L j=this->row_idx[k];
             this->baralpha[j]+=this->lambda_f[i]*deltaalphai*this->A[k];
           }
         }
        // cout<<"update_baralpha"<<"aitg="<<aitg<<endl;

       for(L j=0;j<this->nfeatures;j++)
          primal_w[j]=tilde_x[j];
       this->current_nb_iters=0;
       this->last_update_i.clear();
       this->last_update_i.resize(this->nfeatures,0);
       tilde_x.clear();
       tilde_x.resize(this->nfeatures,0);
     }
   }

   D compute_AiT_tildex(L i) //This function compute A_i^\top \tilde_x
   {
     D res=0;
     for (L k = this->ptr[i]; k < this->ptr[i + 1];k++)
     {
       L j=this->row_idx[k];
       if(this->current_nb_iters!=this->last_update_i[j])
       {
         D xj=compute_current_xj_value(this->baralpha[j], j,this->last_update_i[j],this->current_nb_iters);
         update_x(xj,j);
       }
       res+=this->A[k]*tilde_x[j];
       this->last_update_i[j]=this->current_nb_iters;
     }
     return res;
   }

  void original_Katyusha(vector<D> & x0, vector<D> & w0, string filename, D L_phi, D val_mu, D val_epsilon, L max_nb, L nb_tau, L nb_c, L u, L p_mod, D scal_p)
  {
    filename="Original_Katyusha"+filename;
    this->loopless( x0,  w0,  filename,  L_phi,  val_mu,  val_epsilon, max_nb, nb_tau, nb_c, u, p_mod,scal_p);
  }












  };

  #endif /* MIN_SMOOTH_CONVEX_H */
