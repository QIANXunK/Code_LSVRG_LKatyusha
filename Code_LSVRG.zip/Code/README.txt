General instruction


The matrices should be entered either in LIBSVM format. 

We include in the folder datas/ three datasets ijcnn1, w8a, a9a downloaded from https://www.csie.ntu.edu.tw/~cjlin/libsvm/, that are used in our experiments.




To compile, please do:

>> cd PUT_PATH_TO_ROOT_WHERE_THIS_README_FILE_IS
>> make


>> ./test arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8

arg1: filename;
arg2: algorithm;
arg3: size of the mini-batch;
arg4: maximum number of epochs;
arg5: accuracy;
arg6 (optional): print every arg6 number of epochs; 
arg7 (optional): lambda1; default value=0;
arg8 (optional): lambda2; default value=1e-5;

For example, to solve the logistic regression problem (22) with lambda1=0, lambda2=1e-5 in the paper, using SDCA mini-batch size 20, up to accuracy 1e-7, within 100 iterations, do: 

>>./test ijcnn1 SDCA 20 100 1e-7 

If instead you want to solve the problem with lambda1=0.1, lambda2=1e-6, and would like to record the primal dual gap decrease every 3 epochs, do:

>>./test ijcnn1 SDCA 20 100 1e-7 3 0.1 1e-6




The results are saved in the folder results/.




This code comes as is, with no guarantee. We did not perform extensive testings. We welcome any suggestion to solve bugs or improve the code.

Reproduction of figures in the paper

To reproduce Figure 1 in our paper, do:

>> cd PUT_PATH_TO_ROOT_WHERE_THIS_README_FILE_IS
>> make
>> ./test ijcnn1 SDCA 1 3000 1e-10 1
>> ./test ijcnn1 SDCA 10 3000 1e-10 1
>> ./test ijcnn1 SDCA 50 3000 1e-10 1
>> ./test ijcnn1 SAGA 1 3000 1e-10 1
>> ./test ijcnn1 SAGA 10 3000 1e-10 1
>> ./test ijcnn1 SAGA 50 3000 1e-10 1

Then run

>>cd Matlab_Code/
>>Matlab myplot_tau



To reproduce Figure 2(a) in the paper, do:

>> cd PUT_PATH_TO_ROOT_WHERE_THIS_README_FILE_IS
>> make
>> ./test ijcnn1 SAGA 1 3000 1e-10 1
>> ./test ijcnn1 SAGA 10 3000 1e-10 1
>> ./test ijcnn1 SAGA 50 3000 1e-10 1

Then run

>>cd Matlab_Code/
>>Matlab myplot_tau_vs_ind


Figure 2(b) can be reproduced in the same way by changing the filename ijcnn1 to w8a. You also need to change the name in Matlab_Code/myplot_tau_vs_ind.m


To reproduce Figure 3(a) in the paper, do:

>> cd PUT_PATH_TO_ROOT_WHERE_THIS_README_FILE_IS
>> make
>> ./test ijcnn1 SAGA 1 1000 1e-10 1 0 0


>> cd ../CD
>> make
>> ./test ijcnn1 CD 1 1000 1e-10 1 0 0

>> cd ../Matlab_Code/
>> Matlab myplot_vspcdm
All the plots are saved in .eps format in the folder Matlab_Code/myplots/
