#ifndef LOGIS_LOSS_H
#define LOGIS_LOSS_H


#include "Min_smooth_convex.h"


template<typename L, typename D>
class logis_loss: public Min_smooth_convex<L, D>{
  
  typedef std::map<L, D> row_vec;
   typedef std::map<L, row_vec> sparse_mat;
   typedef typename row_vec::const_iterator col_iter;
   typedef typename sparse_mat::const_iterator row_iter;
  
  public:
   
   
  logis_loss(const char* matrix_file, const char* vector_file, D val_lambda)
  :Min_smooth_convex<L,D>(matrix_file,vector_file,val_lambda)
  {
  }
 
   logis_loss()
  :Min_smooth_convex<L,D>()
  {
  }
 

  void set_Lip()
 {
   this->Lip_max=0;
   this->Lip_vec.resize(this->n);
   row_vec row_i;
   col_iter it;
   D lv=0;
   for(L i=0;i<this->n;i++)
   {
     row_i=this->mat[i];
     for(it=row_i.begin();it!=row_i.end();++it)
       lv+=pow(it->second,2.0);
     lv=lv+this->lambda;
     this->Lip_vec[i]=lv;
     if(lv>this->Lip_max) this->Lip_max=lv;
     lv=0;
   }
 }
 
 
 
   
    inline void gradient_of_fi(L i,const std::vector<D> & x0,row_vec & g0)
   {
     D inpr=inner_product(x0,this->mat[i]);
     D yi=this->b[i];
     D alpha0=-yi+1/(1+exp(-inpr));
     sumoftwovectors(alpha0,this->mat[i], x0, g0);
   }
   
    inline D coordinate_gradient_of_fi(L i, L j, const std::vector<D> & x0)
   {
     D inpr=inner_product(x0,this->mat[i]);
     D yi=this->b[i];
     D alpha0=-yi+1/(1+exp(-inpr));
     return alpha0*this->mat[i][j]+this->lambda*x0[j];
   }
   
    inline D value_of_fi(L i, const std::vector<D> & x0)
   {
     D inpr=inner_product(x0,this->mat[i]);
     D expinpr=exp(-inpr);
     D yi=this->b[i];
     //cout<<" inpr  : " <<inpr <<" , expinpr: "<<expinpr; 
     D ans=-(yi*log(1./(1+expinpr))+(1-yi)*(-inpr-log(1+expinpr)))+this->lambda/2.*square_norm(x0);
     return ans;
   }
   
   
};

#endif /* SQUARE_LOSS_H */